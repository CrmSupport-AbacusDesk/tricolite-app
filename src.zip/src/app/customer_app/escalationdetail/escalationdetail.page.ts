import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-escalationdetail',
  templateUrl: './escalationdetail.page.html',
  styleUrls: ['./escalationdetail.page.scss'],
})
export class EscalationdetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log('helllllllllllllllooooooooooo');
  }

}
